package edu.unict.tswd.springboot.FirstApp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FirstAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
