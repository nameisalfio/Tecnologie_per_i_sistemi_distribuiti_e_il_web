#include <stdio.h>

int      printf(const char *, ...);

int main()
{
	printf("hello world!\n");
}