/* getmsg.h */

void getmsg_max(int sockfd);
void getmsg_tout(int sockfd);
void getmsg_blk(int sockfd);
