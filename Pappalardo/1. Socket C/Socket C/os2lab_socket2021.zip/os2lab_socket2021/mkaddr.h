int mkaddr(struct sockaddr_in * skaddr, char * ipaddr, u_int16_t port);
