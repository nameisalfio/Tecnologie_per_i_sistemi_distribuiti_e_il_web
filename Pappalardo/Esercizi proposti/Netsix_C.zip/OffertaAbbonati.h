#ifndef OFFERTAABBONATI_H
#define OFFERTAABBONATI_H

extern char* serietv[];
extern int episodi[];

int getDisponibilita(char* , int);

#endif