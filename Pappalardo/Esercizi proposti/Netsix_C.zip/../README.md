# NetSix
Applicazione Client/Server che simula un servizio di streaming. 

Un noto distributore di contenuti video on-demand, NetSix, è famoso a livello internazionale per essere l’unico a rendere disponibili ben 6 serie tv , ognuna composta da un certo numero di episodi.

Il server espone un servizio interrogabile tramite socket sulla porta 39999,
che accetta a messaggi nel formato

nome_serie,n

con cui un client chiede se è disponibile l’episodio n della serie 'nome_serie ' (il carattere virgola fa da separatore).

Per semplicità, si supponga che il server legga la richiesta del cliente con un singolo read().

Il server risponde alla richiesta con la stringa 'Disponibile' se l’episodio è presente nel sistema, o 'ComingSoon' se l’episodio o la serie richiesta non sono attualmente disponibili.

L’elenco delle 6 serie tv (popolabile a piacere), con il rispettivo numero di episodi, deve essere gestito in un componente (classe Java o file C) separato chiamato OffertaAbbonati.
Questo esporta, per NetSixServer, il metodo/funzione getDisponibilita(nome_serie, n)
che restituisce:
  1 se l’episodio richiesto, n, è disponibile per la serie nome_serie; 
  0 se n non è disponibile per nome_serie; 
  -1 se nome_serie è disponibile

L’esercizio può essere risolto sia usando C che Java. 

Testare il servizio con un semplice client o con telnet.