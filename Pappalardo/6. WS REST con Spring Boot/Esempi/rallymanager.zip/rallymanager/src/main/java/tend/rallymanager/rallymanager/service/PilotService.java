package tend.rallymanager.rallymanager.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Example;
import org.springframework.stereotype.Service;

import tend.rallymanager.rallymanager.domain.Pilot;
import tend.rallymanager.rallymanager.repository.PilotRepository;

@Service
public class PilotService {

    @Autowired
    private PilotRepository repository;

    public Pilot addPilot(Pilot e) {
        return repository.save(e);
    }

    public Optional<Pilot> getPilot(Long id) {
        return repository.findById(id);
    }

    public List<Pilot> getAllPilots() {
        return repository.findAll();
    }

    public List<Pilot> getPilotsByExample(Pilot e) {
        return repository.findAll(Example.of(e));
    }

    public List<Pilot> getPilotsByCountry(String id) {
        return repository.findByCountryId(id);
    }

    public Pilot updatePilot(Pilot e) {
        return repository.save(e);
    }

    public void deletePilot(Pilot e) {
        repository.delete(e);
    }

    public void deletePilot(Long id) {
        repository.deleteById(id);
    }
}
