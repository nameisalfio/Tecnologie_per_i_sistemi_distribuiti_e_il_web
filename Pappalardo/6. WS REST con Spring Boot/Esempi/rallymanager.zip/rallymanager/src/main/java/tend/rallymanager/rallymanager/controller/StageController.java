package tend.rallymanager.rallymanager.controller;

import java.net.URI;
import java.net.URISyntaxException;
import java.util.List;
import java.util.Optional;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import tend.rallymanager.rallymanager.domain.Rally;
import tend.rallymanager.rallymanager.domain.Stage;
import tend.rallymanager.rallymanager.service.ChampionshipService;
import tend.rallymanager.rallymanager.service.RallyService;
import tend.rallymanager.rallymanager.service.StageService;

@RestController
@RequestMapping("/api")
public class StageController {

    @Autowired
    private StageService service;
    @Autowired
    private ChampionshipService championshipService;
    @Autowired
    private RallyService rallyService;

    @GetMapping("/stage")
    public ResponseEntity<List<Stage>> getStages(@RequestBody Stage e) {
        List<Stage> entityList = service.getStagesByExample(e);
        return ResponseEntity.ok(entityList);
    }

    @GetMapping("/stage/all")
    public ResponseEntity<List<Stage>> getAllStages() {
        List<Stage> entityList = service.getAllStages();
        return ResponseEntity.ok(entityList);
    }

    @GetMapping("/stage/{id}")
    public ResponseEntity<Stage> getStage(@PathVariable Long id) {
        Optional<Stage> entity = service.getStage(id);
        if (entity.isPresent())
            return ResponseEntity.ok(entity.get());
        else
            return ResponseEntity.notFound().build();
    }

    @GetMapping("/rally/{id}/stage")
    public ResponseEntity<List<Stage>> getStagesByRally(@PathVariable Long id) {
        if (rallyService.getRally(id).isEmpty()) {
            return ResponseEntity.notFound().build();
        }
        List<Stage> entityList = service.getStagesByRallyId(id);
        return ResponseEntity.ok(entityList);
    }

    @GetMapping("/championship/{id}/stage")
    public ResponseEntity<List<Stage>> getStagesByCahmpionship(@PathVariable Long id) {
        if (championshipService.getChampionship(id).isEmpty()) {
            return ResponseEntity.notFound().build();
        }
        List<Stage> entityList = service.getStagesByChampionshipId(id);
        return ResponseEntity.ok(entityList);
    }

    @GetMapping("/championship/{cId}/rally/{rId}/stage")
    public ResponseEntity<List<Stage>> getStagesByCahmpionshipAndRally(@PathVariable Long cId, @PathVariable Long rId) {
        if (championshipService.getChampionship(cId).isEmpty() || rallyService.getRally(rId).isEmpty()) {
            return ResponseEntity.notFound().build();
        }
        List<Stage> entityList = service.getStagesByChampionshipIdAndRallyId(cId, rId);
        return ResponseEntity.ok(entityList);
    }

    @PostMapping("/stage")
    public ResponseEntity<Stage> addStage(@Valid @RequestBody Stage e) throws URISyntaxException {
        if (e.getId() != null || e.getRally() == null) {
            return ResponseEntity.badRequest().build();
        }
        Optional<Rally> rally = rallyService.getRally(e.getRally().getId());
        if (rally.isEmpty()) {
            return ResponseEntity.notFound().build();
        }
        e.setRally(rally.get());
        Stage entity = service.addStage(e);
        return ResponseEntity.created(new URI("/api/" + entity.getId())).body(entity);
    }

    @PutMapping("/stage")
    public ResponseEntity<Stage> updateStage(@Valid @RequestBody Stage e) {
        if (e.getId() == null)
            return ResponseEntity.notFound().build();
        Stage entity = service.updateStage(e);
        return ResponseEntity.ok(entity);
    }

    @DeleteMapping("/stage/{id}")
    public ResponseEntity<Void> deleteStage(@PathVariable Long id) {
        if (service.getStage(id).isEmpty()) {
            return ResponseEntity.notFound().build();
        }

        service.deleteStage(id);
        return ResponseEntity.ok().build();
    }
}