package tend.rallymanager.rallymanager.controller;

import java.net.URI;
import java.net.URISyntaxException;
import java.time.LocalTime;
import java.util.List;
import java.util.Optional;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.format.annotation.DateTimeFormat.ISO;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import tend.rallymanager.rallymanager.domain.Participant;
import tend.rallymanager.rallymanager.domain.Result;
import tend.rallymanager.rallymanager.domain.Stage;
import tend.rallymanager.rallymanager.service.ChampionshipService;
import tend.rallymanager.rallymanager.service.ParticipantService;
import tend.rallymanager.rallymanager.service.PilotService;
import tend.rallymanager.rallymanager.service.RallyService;
import tend.rallymanager.rallymanager.service.ResultService;
import tend.rallymanager.rallymanager.service.StageService;

@RestController
@RequestMapping("/api")
public class ResultController {

    @Autowired
    private ResultService service;
    @Autowired
    private ChampionshipService championshipService;
    @Autowired
    private RallyService rallyService;
    @Autowired
    private StageService stageService;
    @Autowired
    private ParticipantService participantService;
    @Autowired
    private PilotService pilotService;

    @GetMapping("/result")
    public ResponseEntity<List<Result>> getResults(@RequestBody Result e) {
        List<Result> entityList = service.getResultsByExample(e);
        return ResponseEntity.ok(entityList);
    }

    @GetMapping("/result/all")
    public ResponseEntity<List<Result>> getAllResults() {
        List<Result> entityList = service.getAllResults();
        return ResponseEntity.ok(entityList);
    }

    @GetMapping("/result/{id}")
    public ResponseEntity<Result> getResult(@PathVariable Long id) {
        Optional<Result> entity = service.getResult(id);
        if (entity.isPresent())
            return ResponseEntity.ok(entity.get());
        else
            return ResponseEntity.notFound().build();
    }

    @GetMapping("championship/{id}/result")
    public ResponseEntity<List<Result>> getResultsByChampionship(@PathVariable Long id) {
        if (championshipService.getChampionship(id).isEmpty()) {
            return ResponseEntity.notFound().build();
        }
        List<Result> entityList = service.getResultsByChampionshipId(id);
        return ResponseEntity.ok(entityList);
    }

    @GetMapping("rally/{id}/result")
    public ResponseEntity<List<Result>> getResultsByRally(@PathVariable Long id) {
        if (rallyService.getRally(id).isEmpty()) {
            return ResponseEntity.notFound().build();
        }
        List<Result> entityList = service.getResultsByRallyId(id);
        return ResponseEntity.ok(entityList);
    }

    @GetMapping("stage/{id}/result")
    public ResponseEntity<List<Result>> getResultsByStage(@PathVariable Long id) {
        if (stageService.getStage(id).isEmpty()) {
            return ResponseEntity.notFound().build();
        }
        List<Result> entityList = service.getResultsByStageId(id);
        return ResponseEntity.ok(entityList);
    }

    @GetMapping("participant/{id}/result")
    public ResponseEntity<List<Result>> getResultsByParticipant(@PathVariable Long id) {
        if (participantService.getParticipant(id).isEmpty()) {
            return ResponseEntity.notFound().build();
        }
        List<Result> entityList = service.getResultsByPartecipantId(id);
        return ResponseEntity.ok(entityList);
    }

    @GetMapping("pilot/{id}/result")
    public ResponseEntity<List<Result>> getResultsByPilot(@PathVariable Long id) {
        if (pilotService.getPilot(id).isEmpty()) {
            return ResponseEntity.notFound().build();
        }
        List<Result> entityList = service.getResultsByPilotId(id);
        return ResponseEntity.ok(entityList);
    }

    @GetMapping("/result/better/{maxTime}")
    public ResponseEntity<List<Result>> getResultsLessThan(
            @PathVariable @DateTimeFormat(iso = ISO.TIME) LocalTime maxTime) {
        List<Result> entityList = service.getResultsLessThanTime(maxTime);
        return ResponseEntity.ok(entityList);
    }

    @PostMapping("/result")
    public ResponseEntity<Result> addResult(@Valid @RequestBody Result e) throws URISyntaxException {
        if (e.getId() != null || e.getParticipant() == null || e.getStage() == null
                || service.existsResultByStageIdAndParticipantId(e.getStage().getId(), e.getParticipant().getId())) {
            return ResponseEntity.badRequest().build();
        }
        Optional<Stage> stage = stageService.getStage(e.getStage().getId());
        Optional<Participant> participant = participantService.getParticipant(e.getParticipant().getId());
        if (stage.isEmpty() || participant.isEmpty()) {
            return ResponseEntity.notFound().build();
        }
        e.setStage(stage.get());
        e.setParticipant(participant.get());
        Result entity = service.addResult(e);
        return ResponseEntity.created(new URI("/api/" + entity.getId())).body(entity);
    }

    @PutMapping("/result")
    public ResponseEntity<Result> updateResult(@Valid @RequestBody Result e) {
        if (e.getParticipant() == null || e.getStage() == null
                || service.existsResultByStageIdAndParticipantId(e.getStage().getId(), e.getParticipant().getId())) {
            return ResponseEntity.badRequest().build();
        }
        Optional<Stage> stage = stageService.getStage(e.getStage().getId());
        Optional<Participant> participant = participantService.getParticipant(e.getParticipant().getId());
        if (e.getId() == null || stage.isEmpty() || participant.isEmpty()) {
            return ResponseEntity.notFound().build();
        }
        e.setStage(stage.get());
        e.setParticipant(participant.get());
        Result entity = service.updateResult(e);
        return ResponseEntity.ok(entity);
    }

    @DeleteMapping("/result/{id}")
    public ResponseEntity<Void> deleteResult(@PathVariable Long id) {
        if (service.getResult(id).isEmpty()) {
            return ResponseEntity.notFound().build();
        }

        service.deleteResult(id);
        return ResponseEntity.ok().build();
    }
}