package tend.rallymanager.rallymanager.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Example;
import org.springframework.stereotype.Service;

import tend.rallymanager.rallymanager.domain.Participant;
import tend.rallymanager.rallymanager.repository.ParticipantRepository;

@Service
public class ParticipantService {

    @Autowired
    private ParticipantRepository repository;

    public Participant addParticipant(Participant e) {
        return repository.save(e);
    }

    public Optional<Participant> getParticipant(Long id) {
        return repository.findById(id);
    }

    public List<Participant> getAllParticipants() {
        return repository.findAll();
    }

    public List<Participant> getParticipantsByExample(Participant e) {
        return repository.findAll(Example.of(e));
    }

    public List<Participant> getParticipantByCarId(Long id){
        return repository.findByCarId(id);
    }

    public List<Participant> getParticipantByChampionshipId(Long id){
        return repository.findByChampionshipId(id);
    }

    public List<Participant> getParticipantByPilotId(Long id){
        return repository.findByPilotId(id);
    }

    public Participant updateParticipant(Participant e) {
        return repository.save(e);
    }

    public void deleteParticipant(Participant e) {
        repository.delete(e);
    }

    public void deleteParticipant(Long id) {
        repository.deleteById(id);
    }
}