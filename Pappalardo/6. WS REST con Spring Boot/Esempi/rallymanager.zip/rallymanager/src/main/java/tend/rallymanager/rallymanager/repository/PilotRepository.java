package tend.rallymanager.rallymanager.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import tend.rallymanager.rallymanager.domain.Pilot;

@Repository
public interface PilotRepository extends JpaRepository<Pilot, Long> {
    List<Pilot> findByCountryId(String id);
}