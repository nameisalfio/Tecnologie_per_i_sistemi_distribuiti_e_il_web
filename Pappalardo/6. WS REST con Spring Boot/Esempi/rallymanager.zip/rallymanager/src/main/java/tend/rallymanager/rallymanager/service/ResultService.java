package tend.rallymanager.rallymanager.service;

import java.time.LocalTime;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Example;
import org.springframework.stereotype.Service;

import tend.rallymanager.rallymanager.domain.Result;
import tend.rallymanager.rallymanager.repository.ResultRepository;

@Service
public class ResultService {

    @Autowired
    private ResultRepository repository;

    public Result addResult(Result e) {
        return repository.save(e);
    }

    public Optional<Result> getResult(Long id) {
        return repository.findById(id);
    }

    public List<Result> getAllResults() {
        return repository.findAll();
    }

    public List<Result> getResultsByExample(Result e) {
        return repository.findAll(Example.of(e));
    }

    public List<Result> getResultsByChampionshipId(Long id) {
        return repository.findByStageRallyChampionshipIdOrderByTime(id);
    }

    public List<Result> getResultsByRallyId(Long id) {
        return repository.findByStageRallyIdOrderByTime(id);
    }

    public List<Result> getResultsByStageId(Long id) {
        return repository.findByStageIdOrderByTime(id);
    }

    public List<Result> getResultsByPilotId(Long id) {
        return repository.findByParticipantPilotIdOrderByTime(id);
    }

    public List<Result> getResultsByPartecipantId(Long id) {
        return repository.findByParticipantIdOrderByTime(id);
    }

    public List<Result> getResultsLessThanTime(LocalTime maxTime) {
        return repository.findByTimeLessThanOrderByTime(maxTime);
    }

    public boolean existsResultByStageIdAndParticipantId(Long sId, Long pId) {
        return repository.existsByStageIdAndParticipantId(sId, pId);
    }

    public Result updateResult(Result e) {
        return repository.save(e);
    }

    public void deleteResult(Result e) {
        repository.delete(e);
    }

    public void deleteResult(Long id) {
        repository.deleteById(id);
    }
}