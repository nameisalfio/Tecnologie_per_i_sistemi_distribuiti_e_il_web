package tend.rallymanager.rallymanager.controller;

import java.net.URI;
import java.net.URISyntaxException;
import java.util.List;
import java.util.Optional;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import tend.rallymanager.rallymanager.domain.Car;
import tend.rallymanager.rallymanager.service.CarService;

@RestController
@RequestMapping("/api/car")
public class CarController {

    @Autowired
    private CarService service;

    @GetMapping
    public ResponseEntity<List<Car>> getCars(@RequestBody Car car) {
        List<Car> entityList = service.getCarsByExample(car);
        return ResponseEntity.ok(entityList);
    }

    @GetMapping("/all")
    public ResponseEntity<List<Car>> getAllCars() {
        List<Car> entityList = service.getAllCars();
        return ResponseEntity.ok(entityList);
    }

    @GetMapping("/{id}")
    public ResponseEntity<Car> getCar(@PathVariable long id) {
        Optional<Car> entity = service.getCar(id);
        if (entity.isPresent())
            return ResponseEntity.ok(entity.get());
        else
            return ResponseEntity.notFound().build();
    }

    @PostMapping
    public ResponseEntity<Car> addCar(@Valid @RequestBody Car e) throws URISyntaxException {
        if (e.getId() != null) {
            return ResponseEntity.badRequest().build();
        }
        Car entity = service.addCar(e);
        return ResponseEntity.created(new URI("/api/car/" + entity.getId())).body(entity);
    }

    @PutMapping
    public ResponseEntity<Car> updateCar(@Valid @RequestBody Car e) {
        if (e.getId() == null)
            return ResponseEntity.notFound().build();
        Car entity = service.updateCar(e);
        return ResponseEntity.ok(entity);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteCar(@PathVariable long id) {
        if (service.getCar(id).isEmpty())
            return ResponseEntity.notFound().build();

        service.deleteCar(id);
        return ResponseEntity.ok().build();
    }
}
