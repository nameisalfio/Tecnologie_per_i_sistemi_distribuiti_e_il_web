package tend.rallymanager.rallymanager.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import tend.rallymanager.rallymanager.domain.Participant;

@Repository
public interface ParticipantRepository extends JpaRepository<Participant, Long> {
    List<Participant> findByChampionshipId(Long championship);
    List<Participant> findByCarId(Long car);
    List<Participant> findByPilotId(Long pilot);
}
