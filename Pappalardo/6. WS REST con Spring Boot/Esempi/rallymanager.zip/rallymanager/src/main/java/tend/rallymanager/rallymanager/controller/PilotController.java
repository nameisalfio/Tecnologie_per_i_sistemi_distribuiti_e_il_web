package tend.rallymanager.rallymanager.controller;

import java.net.URI;
import java.net.URISyntaxException;
import java.util.List;
import java.util.Optional;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import tend.rallymanager.rallymanager.domain.Pilot;
import tend.rallymanager.rallymanager.service.CountryService;
import tend.rallymanager.rallymanager.service.PilotService;

@RestController
@RequestMapping("/api")
public class PilotController {

    @Autowired
    private PilotService service;
    @Autowired
    private CountryService countryService;

    @GetMapping("/pilot")
    public ResponseEntity<List<Pilot>> getPilots(@RequestBody Pilot e) {
        List<Pilot> entityList = service.getPilotsByExample(e);
        return ResponseEntity.ok(entityList);
    }

    @GetMapping("/pilot/all")
    public ResponseEntity<List<Pilot>> getAllPilots() {
        List<Pilot> entityList = service.getAllPilots();
        return ResponseEntity.ok(entityList);
    }

    @GetMapping("/pilot/{id}")
    public ResponseEntity<Pilot> getPilot(@PathVariable Long id) {
        Optional<Pilot> entity = service.getPilot(id);
        if (entity.isPresent())
            return ResponseEntity.ok(entity.get());
        else
            return ResponseEntity.notFound().build();
    }

    @GetMapping("/country/{id}/pilot")
    public ResponseEntity<List<Pilot>> getPilotsByCountry(@PathVariable String id) {
        if (countryService.getCountry(id).isEmpty()) {
            return ResponseEntity.notFound().build();
        }
        List<Pilot> entityList = service.getPilotsByCountry(id);
        return ResponseEntity.ok(entityList);
    }

    @PostMapping("/pilot")
    public ResponseEntity<Pilot> addPilot(@Valid @RequestBody Pilot e) throws URISyntaxException {
        if (e.getId() != null || e.getCountry() == null) {
            return ResponseEntity.badRequest().build();
        }
        if (countryService.getCountry(e.getCountry().getId()).isEmpty()) {
            return ResponseEntity.notFound().build();
        }
        Pilot entity = service.addPilot(e);
        return ResponseEntity.created(new URI("/api/pilot/" + entity.getId())).body(entity);
    }

    @PutMapping("/pilot")
    public ResponseEntity<Pilot> updatePilot(@Valid @RequestBody Pilot e) {
        if (e.getCountry() == null) {
            return ResponseEntity.badRequest().build();
        }
        if (e.getId() == null || countryService.getCountry(e.getCountry().getId()).isEmpty()) {
            return ResponseEntity.notFound().build();
        }
        Pilot entity = service.updatePilot(e);
        return ResponseEntity.ok(entity);
    }

    @DeleteMapping("/pilot/{id}")
    public ResponseEntity<Void> deletePilot(@PathVariable Long id) {
        if (service.getPilot(id).isEmpty())
            return ResponseEntity.notFound().build();

        service.deletePilot(id);
        return ResponseEntity.ok().build();
    }
}