package tend.rallymanager.rallymanager.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Example;
import org.springframework.stereotype.Service;

import tend.rallymanager.rallymanager.domain.Stage;
import tend.rallymanager.rallymanager.repository.StageRepository;

@Service
public class StageService {

    @Autowired
    private StageRepository repository;

    public Stage addStage(Stage e) {
        return repository.save(e);
    }

    public Optional<Stage> getStage(Long id) {
        return repository.findById(id);
    }

    public List<Stage> getAllStages() {
        return repository.findAll();
    }

    public List<Stage> getStagesByExample(Stage e) {
        return repository.findAll(Example.of(e));
    }

    public List<Stage> getStagesByRallyId(Long id) {
        return repository.findByRallyId(id);
    }

    public List<Stage> getStagesByChampionshipId(Long id) {
        return repository.findByRallyChampionshipId(id);
    }

    public List<Stage> getStagesByChampionshipIdAndRallyId(Long cId, Long rId) {
        return repository.findByRallyChampionshipIdAndRallyId(cId, rId);
    }

    public Stage updateStage(Stage e) {
        return repository.save(e);
    }

    public void deleteStage(Stage e) {
        repository.delete(e);
    }

    public void deleteStage(Long id) {
        repository.deleteById(id);
    }
}