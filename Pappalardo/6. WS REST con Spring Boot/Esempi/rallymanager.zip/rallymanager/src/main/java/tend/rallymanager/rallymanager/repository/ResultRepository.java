package tend.rallymanager.rallymanager.repository;

import java.time.LocalTime;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import tend.rallymanager.rallymanager.domain.Result;

@Repository
public interface ResultRepository extends JpaRepository<Result, Long> {
    List<Result> findByStageIdOrderByTime(Long id);
    List<Result> findByParticipantIdOrderByTime(Long id);
    List<Result> findByStageRallyIdOrderByTime(Long id);
    List<Result> findByStageRallyChampionshipIdOrderByTime(Long id);
    List<Result> findByParticipantPilotIdOrderByTime(Long id);
    List<Result> findByTimeLessThanOrderByTime(LocalTime maxResult);
    boolean existsByStageIdAndParticipantId(Long sId, Long pId);
}