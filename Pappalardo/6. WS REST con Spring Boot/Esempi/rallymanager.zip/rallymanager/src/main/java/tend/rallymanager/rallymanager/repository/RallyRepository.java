package tend.rallymanager.rallymanager.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import tend.rallymanager.rallymanager.domain.Rally;

@Repository
public interface RallyRepository extends JpaRepository<Rally, Long> {
    List<Rally> findByChampionshipId(Long id);
}