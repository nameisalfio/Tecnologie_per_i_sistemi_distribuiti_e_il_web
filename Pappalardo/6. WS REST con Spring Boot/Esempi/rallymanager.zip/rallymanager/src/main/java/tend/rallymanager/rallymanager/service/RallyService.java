package tend.rallymanager.rallymanager.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Example;
import org.springframework.stereotype.Service;

import tend.rallymanager.rallymanager.domain.Rally;
import tend.rallymanager.rallymanager.repository.RallyRepository;

@Service
public class RallyService {

    @Autowired
    private RallyRepository repository;

    public Rally addRally(Rally e) {
        return repository.save(e);
    }

    public Optional<Rally> getRally(Long id) {
        return repository.findById(id);
    }

    public List<Rally> getAllRallys() {
        return repository.findAll();
    }

    public List<Rally> getRallysByExample(Rally e) {
        return repository.findAll(Example.of(e));
    }

    public List<Rally> getRallyByChampionshipId(Long id) {
        return repository.findByChampionshipId(id);
    }

    public Rally updateRally(Rally e) {
        return repository.save(e);
    }

    public void deleteRally(Rally e) {
        repository.delete(e);
    }

    public void deleteRally(Long id) {
        repository.deleteById(id);
    }
}
