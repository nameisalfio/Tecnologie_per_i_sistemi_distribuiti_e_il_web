package tend.rallymanager.rallymanager.controller;

import java.net.URI;
import java.net.URISyntaxException;
import java.util.List;
import java.util.Optional;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import tend.rallymanager.rallymanager.domain.Championship;
import tend.rallymanager.rallymanager.service.ChampionshipService;

@RestController
@RequestMapping("/api/championship")
public class ChampionshipController {

    @Autowired
    private ChampionshipService service;

    @GetMapping
        public ResponseEntity<List<Championship>> getChampionships(@RequestBody Championship e) {
        List<Championship> entityList = service.getChampionshipsByExample(e);
        return ResponseEntity.ok(entityList);
    }

    @GetMapping("/all")
    public ResponseEntity<List<Championship>> getAllChampionships() {
        List<Championship> entityList = service.getAllChampionships();
        return ResponseEntity.ok(entityList);
    }

    @GetMapping("/{id}")
    public ResponseEntity<Championship> getChampionship(@PathVariable long id) {
        Optional<Championship> entity = service.getChampionship(id);
        if(entity.isPresent())
            return ResponseEntity.ok(entity.get());
        else
            return ResponseEntity.notFound().build();
    }

    @PostMapping
    public ResponseEntity<Championship> addChampionship(@Valid @RequestBody Championship e) throws URISyntaxException {
        if (e.getId() != null) {
            return ResponseEntity.badRequest().build();
        }
        Championship entity = service.addChampionship(e);
        return ResponseEntity.created(new URI("/api/championship/" + entity.getId())).body(entity);
    }

    @PutMapping
    public ResponseEntity<Championship> updateChampionship(@Valid @RequestBody Championship e) {
        if (e.getId() == null)
            return ResponseEntity.notFound().build();
        Championship entity = service.updateChampionship(e);
        return ResponseEntity.ok(entity);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteChampionship(@PathVariable long id) {
        if (service.getChampionship(id).isEmpty())
            return ResponseEntity.notFound().build();

        service.deleteChampionship(id);
        return ResponseEntity.ok().build();
    }
}
