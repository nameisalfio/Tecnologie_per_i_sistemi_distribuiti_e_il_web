package tend.rallymanager.rallymanager.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Example;
import org.springframework.stereotype.Service;

import tend.rallymanager.rallymanager.domain.Country;
import tend.rallymanager.rallymanager.repository.CountryRepository;

@Service
public class CountryService {

    @Autowired
    private CountryRepository repository;

    public Country addCountry(Country e) {
        return repository.save(e);
    }

    public Optional<Country> getCountry(String id) {
        return repository.findById(id);
    }

    public List<Country> getAllCountrys() {
        return repository.findAll();        
    }

    public List<Country> getCountrysByExample(Country e) {
        return repository.findAll(Example.of(e));
    }

    public Country updateCountry(Country e) {
        return repository.save(e);
    }

    public void deleteCountry(Country e) {
        repository.delete(e);
    }

    public void deleteCountry(String id) {
        repository.deleteById(id);
    }
}