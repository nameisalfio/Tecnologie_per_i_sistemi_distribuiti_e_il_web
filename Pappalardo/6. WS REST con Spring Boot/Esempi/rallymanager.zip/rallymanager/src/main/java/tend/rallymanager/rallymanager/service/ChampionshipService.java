package tend.rallymanager.rallymanager.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Example;
import org.springframework.stereotype.Service;

import tend.rallymanager.rallymanager.domain.Championship;
import tend.rallymanager.rallymanager.repository.ChampionshipRepository;

@Service
public class ChampionshipService {

    @Autowired
    private ChampionshipRepository repository;

    public Championship addChampionship(Championship e) {
        return repository.save(e);
    }

    public Optional<Championship> getChampionship(Long id) {
        return repository.findById(id);
    }

    public List<Championship> getAllChampionships() {
        return repository.findAll();
    }

    public List<Championship> getChampionshipsByExample(Championship e) {
        return repository.findAll(Example.of(e));
    }

    public Championship updateChampionship(Championship e) {
        return repository.save(e);
    }

    public void deleteChampionship(Championship e) {
        repository.delete(e);
    }

    public void deleteChampionship(Long id) {
        repository.deleteById(id);
    }
}
