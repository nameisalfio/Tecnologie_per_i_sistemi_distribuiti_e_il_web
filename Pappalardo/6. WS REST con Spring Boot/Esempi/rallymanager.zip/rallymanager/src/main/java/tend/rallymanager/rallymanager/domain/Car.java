package tend.rallymanager.rallymanager.domain;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.validation.constraints.NotBlank;

@Entity
public class Car {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    @NotBlank
    private String model;
    @NotBlank
    private String contructor;
    @NotBlank
    private String category;

    public Car() {
    }

    public Car(Long id, @NotBlank String model, @NotBlank String contructor, @NotBlank String category) {
        this.id = id;
        this.model = model;
        this.contructor = contructor;
        this.category = category;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getModel() {
        return model;
    }

    public void setModel(String model) {
        this.model = model;
    }

    public String getContructor() {
        return contructor;
    }

    public void setContructor(String contructor) {
        this.contructor = contructor;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }
}