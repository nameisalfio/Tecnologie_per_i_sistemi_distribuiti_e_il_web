package tend.rallymanager.rallymanager.controller;

import java.net.URI;
import java.net.URISyntaxException;
import java.util.List;
import java.util.Optional;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import tend.rallymanager.rallymanager.domain.Car;
import tend.rallymanager.rallymanager.domain.Championship;
import tend.rallymanager.rallymanager.domain.Participant;
import tend.rallymanager.rallymanager.domain.Pilot;
import tend.rallymanager.rallymanager.service.CarService;
import tend.rallymanager.rallymanager.service.ChampionshipService;
import tend.rallymanager.rallymanager.service.ParticipantService;
import tend.rallymanager.rallymanager.service.PilotService;

@RestController
@RequestMapping("/api/")
public class ParticipantController {

    @Autowired
    private ParticipantService service;
    @Autowired
    private ChampionshipService championshipService;
    @Autowired
    private CarService carService;
    @Autowired
    private PilotService pilotService;

    @GetMapping("/participant")
    public ResponseEntity<List<Participant>> getParticipants(@RequestBody Participant e) {
        List<Participant> entityList = service.getParticipantsByExample(e);
        return ResponseEntity.ok(entityList);
    }

    @GetMapping("/participant/all")
    public ResponseEntity<List<Participant>> getAllParticipants() {
        List<Participant> entityList = service.getAllParticipants();
        return ResponseEntity.ok(entityList);
    }

    @GetMapping("/participant/{id}")
    public ResponseEntity<Participant> getParticipant(@PathVariable Long id) {
        Optional<Participant> entity = service.getParticipant(id);
        if (entity.isPresent())
            return ResponseEntity.ok(entity.get());
        else
            return ResponseEntity.notFound().build();
    }

    @GetMapping("/championship/{id}/participant")
    public ResponseEntity<List<Participant>> getParticipanstByChampionship(@PathVariable Long id) {
        if (championshipService.getChampionship(id).isEmpty()) {
            return ResponseEntity.notFound().build();
        }
        List<Participant> entityList = service.getParticipantByChampionshipId(id);
        return ResponseEntity.ok(entityList);
    }

    @GetMapping("/pilot/{id}/participant")
    public ResponseEntity<List<Participant>> getParticipanstByPilot(@PathVariable Long id) {
        if (pilotService.getPilot(id).isEmpty()) {
            return ResponseEntity.notFound().build();
        }
        List<Participant> entityList = service.getParticipantByPilotId(id);
        return ResponseEntity.ok(entityList);
    }

    @GetMapping("/car/{id}/participant")
    public ResponseEntity<List<Participant>> getParticipanstByCar(@PathVariable Long id) {
        if (carService.getCar(id).isEmpty()) {
            return ResponseEntity.notFound().build();
        }
        List<Participant> entityList = service.getParticipantByCarId(id);
        return ResponseEntity.ok(entityList);
    }

    @PostMapping("/participant")
    public ResponseEntity<Participant> addParticipant(@Valid @RequestBody Participant e) throws URISyntaxException {
        if (e.getId() != null || e.getCar() == null || e.getPilot() == null || e.getChampionship() == null) {
            return ResponseEntity.badRequest().build();
        }
        Optional<Car> car = carService.getCar(e.getCar().getId());
        Optional<Pilot> pilot = pilotService.getPilot(e.getPilot().getId());
        Optional<Championship> championship = championshipService.getChampionship(e.getChampionship().getId());
        if (car.isEmpty() || pilot.isEmpty() || championship.isEmpty()) {
            return ResponseEntity.notFound().build();
        }
        Participant entity = service.addParticipant(e);
        return ResponseEntity.created(new URI("/api//" + entity.getId())).body(entity);
    }

    @PutMapping("/participant")
    public ResponseEntity<Participant> updateParticipant(@Valid @RequestBody Participant e) {
        if(e.getCar() == null || e.getPilot() == null || e.getChampionship() == null){
            return ResponseEntity.badRequest().build();
        }
        Optional<Car> car = carService.getCar(e.getCar().getId());
        Optional<Pilot> pilot = pilotService.getPilot(e.getPilot().getId());
        Optional<Championship> championship = championshipService.getChampionship(e.getChampionship().getId());
        if (e.getId() == null || car.isEmpty() || pilot.isEmpty() || championship.isEmpty()) {
            return ResponseEntity.notFound().build();
        }
        e.setCar(car.get());
        e.setPilot(pilot.get());
        e.setChampionship(championship.get());
        Participant entity = service.updateParticipant(e);
        return ResponseEntity.ok(entity);
    }

    @DeleteMapping("/participant/{id}")
    public ResponseEntity<Void> deleteParticipant(@PathVariable Long id) {
        if (service.getParticipant(id).isEmpty())
            return ResponseEntity.notFound().build();

        service.deleteParticipant(id);
        return ResponseEntity.ok().build();
    }
}
