package tend.rallymanager.rallymanager.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import tend.rallymanager.rallymanager.domain.Stage;

@Repository
public interface StageRepository extends JpaRepository<Stage, Long> {
    List<Stage> findByRallyId(Long id);
    List<Stage> findByRallyChampionshipId(Long id);
    List<Stage> findByRallyChampionshipIdAndRallyId(Long cId, Long rId);
}
