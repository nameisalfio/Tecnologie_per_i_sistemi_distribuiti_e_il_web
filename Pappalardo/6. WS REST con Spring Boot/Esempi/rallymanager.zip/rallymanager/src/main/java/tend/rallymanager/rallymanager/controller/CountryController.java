package tend.rallymanager.rallymanager.controller;

import java.net.URI;
import java.net.URISyntaxException;
import java.util.List;
import java.util.Optional;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import tend.rallymanager.rallymanager.domain.Country;
import tend.rallymanager.rallymanager.service.CountryService;

@RestController
@RequestMapping("/api/country")
public class CountryController {

    @Autowired
    private CountryService service;

    @GetMapping
    public ResponseEntity<List<Country>> getCountrys(@RequestBody Country e) {
        List<Country> entityList = service.getCountrysByExample(e);
        return ResponseEntity.ok(entityList);
    }

    @GetMapping("/all")
    public ResponseEntity<List<Country>> getAllCountrys() {
        List<Country> entityList = service.getAllCountrys();
        return ResponseEntity.ok(entityList);
    }

    @GetMapping("/{id}")
    public ResponseEntity<Country> getCountry(@PathVariable String id) {
        Optional<Country> entity = service.getCountry(id);
        if (entity.isPresent())
            return ResponseEntity.ok(entity.get());
        else
            return ResponseEntity.notFound().build();
    }

    @PostMapping
    public ResponseEntity<Country> addCountry(@Valid @RequestBody Country e) throws URISyntaxException {
        if (e.getId() == null || service.getCountry(e.getId()).isPresent()) {
            return ResponseEntity.badRequest().build();
        }
        Country entity = service.addCountry(e);
        return ResponseEntity.created(new URI("/api/country/" + entity.getId())).body(entity);
    }

    @PutMapping
    public ResponseEntity<Country> updateCountry(@Valid @RequestBody Country e) {
        if (e.getId() == null)
            return ResponseEntity.notFound().build();
        Country entity = service.updateCountry(e);
        return ResponseEntity.ok(entity);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteCountry(@PathVariable String id) {
        if (service.getCountry(id).isEmpty())
            return ResponseEntity.notFound().build();

        service.deleteCountry(id);
        return ResponseEntity.ok().build();
    }
}
