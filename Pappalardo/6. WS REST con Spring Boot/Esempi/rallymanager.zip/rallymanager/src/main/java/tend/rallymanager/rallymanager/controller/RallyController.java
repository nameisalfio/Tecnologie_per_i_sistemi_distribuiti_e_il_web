package tend.rallymanager.rallymanager.controller;

import java.net.URI;
import java.net.URISyntaxException;
import java.util.List;
import java.util.Optional;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import tend.rallymanager.rallymanager.domain.Championship;
import tend.rallymanager.rallymanager.domain.Country;
import tend.rallymanager.rallymanager.domain.Rally;
import tend.rallymanager.rallymanager.service.ChampionshipService;
import tend.rallymanager.rallymanager.service.CountryService;
import tend.rallymanager.rallymanager.service.RallyService;

@RestController
@RequestMapping("/api")
public class RallyController {

    @Autowired
    private RallyService service;
    @Autowired
    private ChampionshipService championshipService;
    @Autowired
    private CountryService countryService;

    @GetMapping("/rally")
    public ResponseEntity<List<Rally>> getRallys(@RequestBody Rally e) {
        List<Rally> entityList = service.getRallysByExample(e);
        return ResponseEntity.ok(entityList);
    }

    @GetMapping("rally/all")
    public ResponseEntity<List<Rally>> getAllRallys() {
        List<Rally> entityList = service.getAllRallys();
        return ResponseEntity.ok(entityList);
    }

    @GetMapping("rally/{id}")
    public ResponseEntity<Rally> getRally(@PathVariable Long id) {
        Optional<Rally> entity = service.getRally(id);
        if (entity.isPresent())
            return ResponseEntity.ok(entity.get());
        else
            return ResponseEntity.notFound().build();
    }

    @GetMapping("championship/{id}/rally")
    public ResponseEntity<List<Rally>> getRallyByChampionshipId(@PathVariable Long id) {
        if (championshipService.getChampionship(id).isEmpty()) {
            return ResponseEntity.notFound().build();
        }
        List<Rally> entityList = service.getRallyByChampionshipId(id);
        return ResponseEntity.ok(entityList);
    }

    @PostMapping("/rally")
    public ResponseEntity<Rally> addRally(@Valid @RequestBody Rally e) throws URISyntaxException {
        if (e.getId() != null || e.getChampionship() == null || e.getCountry() == null) {
            return ResponseEntity.badRequest().build();
        }
        Optional<Championship> championship = championshipService.getChampionship(e.getChampionship().getId());
        Optional<Country> country = countryService.getCountry(e.getCountry().getId());
        if (championship.isEmpty() || country.isEmpty()) {
            return ResponseEntity.notFound().build();
        }
        Rally entity = service.addRally(e);
        return ResponseEntity.created(new URI("/api/rally/" + entity.getId())).body(entity);
    }

    @PutMapping("rally")
    public ResponseEntity<Rally> updateRally(@Valid @RequestBody Rally e) {
        if (e.getChampionship() == null || e.getCountry() == null) {
            return ResponseEntity.badRequest().build();
        }
        Optional<Championship> championship = championshipService.getChampionship(e.getChampionship().getId());
        Optional<Country> country = countryService.getCountry(e.getCountry().getId());
        if (e.getId() == null || championship.isEmpty() || country.isEmpty()){
            return ResponseEntity.notFound().build();
        }
        e.setChampionship(championship.get());
        e.setCountry(country.get());
        Rally entity = service.updateRally(e);
        return ResponseEntity.ok(entity);
    }

    @DeleteMapping("rally/{id}")
    public ResponseEntity<Void> deleteRally(@PathVariable Long id) {
        if (service.getRally(id).isEmpty())
            return ResponseEntity.notFound().build();

        service.deleteRally(id);
        return ResponseEntity.ok().build();
    }
}
