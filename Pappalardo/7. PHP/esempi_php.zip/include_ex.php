<!DOCTYPE html>
<html>
<body>

<h1>Welcome to my home page!</h1>
<p>Some text.</p>
<p>Some more text.</p>
<?php include_once 'footer.php';?>

<?php include_once 'footer.php';?>

</body>
</html>
