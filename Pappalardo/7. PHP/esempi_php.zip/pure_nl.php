<!-- pure_nl.php -->

<?php
echo "<html>\n";
echo "<body>\n";
echo "Today is ";
echo date("l");
echo "\n</body>\n";
echo "</html>";
