<!-- pure3.php -->
<?php
echo "<html>\n<body>\nToday is ";
echo date("l");
echo "\n</body>\n</html>";