 <?php

require "connect.php";



$conn->close();

?>