<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\StudentController;
use App\Http\Controllers\CourseController;
use App\Http\Controllers\ExamController;

Route::view('/', 'home');

Route::resource('/students', StudentController::class);
Route::post('students/help_show', [StudentController::class, 'help_show']);

Route::resource('/courses', CourseController::class);
Route::post('courses/help_show', [CourseController::class, 'help_show']);

Route::resource('/exams', ExamController::class);
Route::post('exams/help_show', [ExamController::class, 'help_show']);
