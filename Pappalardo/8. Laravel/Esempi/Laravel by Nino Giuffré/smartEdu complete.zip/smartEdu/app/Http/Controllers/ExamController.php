<?php

namespace App\Http\Controllers;

use App\Models\Exam;
use App\Models\Student;
use App\Models\Course;
use Illuminate\Http\Request;

class ExamController extends Controller
{
    public function index()
    {
        $exams = Exam::all();
        return view('exams.index', compact('exams'));
    }

    public function create()
    {
        return view('exams.create');
    }

    public function store()
    {
        $exam = new Exam;
        $exam->student_id = request('student_id');
        $exam->course_id = request('course_id');
        $exam->date = request('date');
        $exam->mark = request('mark');
        Student::findOrFail($exam->student_id);
        Course::findOrFail($exam->course_id);
        if($this->isUnique($exam))
            $exam->save();
        return redirect('/exams');
    }

    public function show(Exam $exam)
    {
        return view('exams.show', compact('exam'));
    }

    public function edit(Exam $exam)
    {
        return view('exams.edit', compact('exam'));
    }

    public function update(Exam $exam)
    {
        $exam->student_id = request('student_id');
        $exam->course_id = request('course_id');
        $exam->date = request('date');
        $exam->mark = request('mark');
        Student::findOrFail($exam->student_id);
        Course::findOrFail($exam->course_id);
        if($this->isValid($exam))
            $exam->save();
        return redirect('/exams');
    }

    public function destroy(Exam $exam)
    {
        $exam->delete();
        return redirect('/exams');
    }

    public function isUnique($new)
    {
        $exams = Exam::all();
        foreach ($exams as $exam)
            if($new->student_id == $exam->student_id and $new->course_id == $exam->course_id)
                return false;
        return true;
    }

    public function isValid($exam)
    {
        $oldStudent = request('oldStudent');
        $oldCourse = request('oldCourse');
        if($exam->student_id == $oldStudent and $exam->course_id == $oldCourse)
            return true;
        else if($this->isUnique($exam))
            return true;
        else
            return false;
    }

    public function help_show()
    {
        $id = request('exam_id');
        return redirect("/exams/$id");
    }
}
