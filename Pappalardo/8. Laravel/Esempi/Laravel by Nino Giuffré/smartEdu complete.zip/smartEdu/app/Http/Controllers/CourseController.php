<?php

namespace App\Http\Controllers;

use App\Models\Course;
use Illuminate\Http\Request;

class CourseController extends Controller
{
    public function index()
    {
        $courses = Course::all();
        return view('courses.index', compact('courses'));
    }

    public function create()
    {
        return view('courses.create');
    }

    public function store()
    {
        $course = new Course;
        $course->name = request('name');
        if($this->isUnique($course))
            $course->save();
        return redirect('/courses');
    }

    public function show(Course $course)
    {
        return view('courses.show', compact('course'));
    }

    public function edit(Course $course)
    {
        return view('courses.edit', compact('course'));
    }

    public function update(Course $course)
    {
        $course->name = request('name');
        if($this->isValid($course))
            $course->save();
        return redirect('/courses');
    }

    public function destroy(Course $course)
    {
        $course->delete();
        return redirect('/courses');
    }

    public function isUnique($new)
    {
        $courses = Course::all();
        foreach ($courses as $course)
            if($new->name == $course->name)
                return false;
        return true;
    }

    public function isValid($course)
    {
        $oldName = request('oldName');
        if($course->name == $oldName)
            return true;
        else if($this->isUnique($course))
            return true;
        else
            return false;
    }

    public function help_show()
    {
        $id = request('course_id');
        return redirect("/courses/$id");
    }
}
