<?php

namespace App\Http\Controllers;

use App\Models\Student;
use Illuminate\Http\Request;

class StudentController extends Controller
{
    public function index()
    {
        $students = Student::all();
        return view('students.index', compact('students'));
    }

    public function create()
    {
        return view('students.create');
    }

    public function store()
    {
        $student = new Student;
        $student->name = request('name');
        $student->code = request('code');
        if($this->isUnique($student))
            $student->save();
        return redirect('/students');
    }

    public function show(Student $student)
    {
        return view('students.show', compact('student'));
    }

    public function edit(Student $student)
    {
        return view('students.edit', compact('student'));
    }

    public function update(Student $student)
    {
        $student->name = request('name');
        $student->code = request('code');
        if($this->isValid($student))
            $student->save();
        return redirect('/students');
    }

    public function destroy(Student $student)
    {
        $student->delete();
        return redirect('/students');
    }

    public function isUnique($new)
    {
        $students = Student::all();
        foreach ($students as $student)
            if($new->code == $student->code)
                return false;
        return true;
    }

    public function isValid($student)
    {
        $oldCode = request('oldCode');
        if($student->code == $oldCode)
            return true;
        else if($this->isUnique($student))
            return true;
        else
            return false;
    }

    public function help_show()
    {
        $id = request('student_id');
        return redirect("/students/$id");
    }
}
