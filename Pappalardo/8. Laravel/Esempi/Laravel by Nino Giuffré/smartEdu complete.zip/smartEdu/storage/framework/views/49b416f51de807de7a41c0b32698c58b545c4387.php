<?php $__env->startSection('content'); ?>
    <h1>Corsi</h1>
    <ul>
        <?php $__currentLoopData = $courses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li>
                <b>ID:</b> <?php echo e($course->id); ?> <br>
                <b>NOME:</b> <?php echo e($course->name); ?> <br><br>
            </li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/kada/LaravelProjects/smartEdu/resources/views/courses/index.blade.php ENDPATH**/ ?>