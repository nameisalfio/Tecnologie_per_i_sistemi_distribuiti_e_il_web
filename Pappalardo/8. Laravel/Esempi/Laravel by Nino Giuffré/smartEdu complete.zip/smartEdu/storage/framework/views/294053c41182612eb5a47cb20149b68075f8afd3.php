<?php $__env->startSection('content'); ?>
    <h1>Crea Studente</h1>
    <form action="/students" method="post">
        <?php echo csrf_field(); ?>
        <label for="name">Nome</label> <br>
        <input type="text" name="name" id="name"> <br><br>
        <label for="code">Matricola</label><br>
        <input type="text" name="code" id="code"> <br><br>
        <input type="submit" value="Crea Studente">
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/kada/LaravelProjects/smartEdu/resources/views/students/create.blade.php ENDPATH**/ ?>