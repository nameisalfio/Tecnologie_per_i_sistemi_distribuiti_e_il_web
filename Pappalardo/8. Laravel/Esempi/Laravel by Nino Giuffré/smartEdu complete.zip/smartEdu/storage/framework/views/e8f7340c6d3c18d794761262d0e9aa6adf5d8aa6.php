<?php $__env->startSection('content'); ?>
    <h1>Studente</h1>
    <b>ID:</b> <?php echo e($student->id); ?> <br>
    <b>NOME:</b> <?php echo e($student->name); ?> <br>
    <b>MATRICOLA:</b> <?php echo e($student->code); ?> <br><br>
    <form action="/students/<?php echo e($student->id); ?>/edit" method="get">
        <input type="submit" value="Modifica/Elimina Studente">
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/kada/LaravelProjects/smartEdu/resources/views/students/show.blade.php ENDPATH**/ ?>