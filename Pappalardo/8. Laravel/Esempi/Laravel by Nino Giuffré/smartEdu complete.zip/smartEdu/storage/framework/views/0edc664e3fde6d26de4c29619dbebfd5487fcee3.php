<?php $__env->startSection('content'); ?>
    <h1>Benvenuto su smartEdu</h1>
    <form action="/students/create" method="get">
        <input type="submit" value="Crea Studente"> <br><br>
    </form>
    <form action="/students" method="get">
        <input type="submit" value="Elenco Studenti"> <br><br>
    </form>
    <form action="/students/help_show" method="post">
        <?php echo csrf_field(); ?>
        <label for="student_id">ID Studente</label> <br>
        <input type="number" name="student_id" id="student_id">
        <input type="submit" value="Cerca Studente"> <br><br><br><br>
    </form>

    <form action="/courses/create" method="get">
        <input type="submit" value="Crea Corso"> <br><br>
    </form>
    <form action="/courses" method="get">
        <input type="submit" value="Elenco Corsi"> <br><br>
    </form>
    <form action="/courses/help_show" method="post">
        <?php echo csrf_field(); ?>
        <label for="course_id">ID Corso</label> <br>
        <input type="number" name="course_id" id="course_id">
        <input type="submit" value="Cerca Corso"> <br><br><br><br>
    </form>

    <form action="/exams/create" method="get">
        <input type="submit" value="Crea Esame"> <br><br>
    </form>
    <form action="/exams" method="get">
        <input type="submit" value="Elenco Esami"> <br><br>
    </form>
    <form action="/exams/help_show" method="post">
        <?php echo csrf_field(); ?>
        <label for="exam_id">ID Esame</label> <br>
        <input type="number" name="exam_id" id="exam_id">
        <input type="submit" value="Cerca Esame"> <br><br><br><br>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/kada/LaravelProjects/smartEdu/resources/views/home.blade.php ENDPATH**/ ?>