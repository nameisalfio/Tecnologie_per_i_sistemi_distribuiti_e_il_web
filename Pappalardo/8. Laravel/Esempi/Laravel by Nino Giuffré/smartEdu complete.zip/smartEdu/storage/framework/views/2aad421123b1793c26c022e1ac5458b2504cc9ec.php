<?php $__env->startSection('content'); ?>
    <h1>Modifica/Elimina Studente</h1>
    <form action="/students/<?php echo e($student->id); ?>" method="post">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PATCH'); ?>
        <label for="name">Nome</label> <br>
        <input type="text" name="name" id="name" value="<?php echo e($student->name); ?>"> <br><br>
        <label for="code">Matricola</label> <br>
        <input type="text" name="code" id="code" value="<?php echo e($student->code); ?>"> <br><br>
        <input type="hidden" name="oldCode" id="oldCode" value="<?php echo e($student->code); ?>">
        <input type="submit" value="Modifica Studente"> <br><br>
    </form>
    <form action="/students/<?php echo e($student->id); ?>" method="post">
        <?php echo csrf_field(); ?>
        <?php echo method_field('DELETE'); ?>
        <input type="submit" value="Elimina Studente">
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/kada/LaravelProjects/smartEdu/resources/views/students/edit.blade.php ENDPATH**/ ?>