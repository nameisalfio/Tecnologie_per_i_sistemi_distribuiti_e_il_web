<?php
    use App\Models\Student;
    use App\Models\Course;

    $student = Student::find($exam->student_id);
    $course = Course::find($exam->course_id);
?>

<?php $__env->startSection('content'); ?>
    <h1>Esame</h1>
    <b>ID:</b> <?php echo e($exam->id); ?> <br>
    <b>STUDENTE:</b> <?php echo e($student->name); ?> <br>
    <b>MATRICOLA:</b> <?php echo e($student->code); ?> <br>
    <b>CORSO:</b> <?php echo e($course->name); ?> <br>
    <b>DATA:</b> <?php echo e($exam->date); ?> <br>
    <b>VOTO:</b> <?php echo e($exam->mark); ?> <br><br>
    <form action="/exams/<?php echo e($exam->id); ?>/edit" method="get">
        <input type="submit" value="Modifica/Elimina Esame">
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/kada/LaravelProjects/smartEdu/resources/views/exams/show.blade.php ENDPATH**/ ?>