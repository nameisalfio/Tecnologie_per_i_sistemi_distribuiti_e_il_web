<?php $__env->startSection('content'); ?>
    <h1>Studenti</h1>
    <ul>
        <?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li>
                <b>ID:</b> <?php echo e($student->id); ?> <br>
                <b>NOME:</b> <?php echo e($student->name); ?> <br>
                <b>MATRICOLA:</b> <?php echo e($student->code); ?> <br><br>
            </li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/kada/LaravelProjects/smartEdu/resources/views/students/index.blade.php ENDPATH**/ ?>