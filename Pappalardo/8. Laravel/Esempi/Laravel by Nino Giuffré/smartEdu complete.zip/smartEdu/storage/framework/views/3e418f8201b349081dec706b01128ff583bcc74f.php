<?php $__env->startSection('content'); ?>
    <h1>Modifica/Elimina Esame</h1>
    <form action="/exams/<?php echo e($exam->id); ?>" method="post">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PATCH'); ?>
        <label for="student_id">ID Studente</label> <br>
        <input type="number" name="student_id" id="student_id" value="<?php echo e($exam->student_id); ?>"> <br><br>
        <input type="hidden" name="oldStudent" id="oldStudent" value="<?php echo e($exam->student_id); ?>">
        <label for="course_id">ID Corso</label> <br>
        <input type="number" name="course_id" id="course_id" value="<?php echo e($exam->course_id); ?>"> <br><br>
        <input type="hidden" name="oldCourse" id="oldCourse" value="<?php echo e($exam->course_id); ?>">
        <label for="date">Date</label> <br>
        <input type="date" name="date" id="date" value="<?php echo e($exam->date); ?>"> <br><br>
        <label for="mark">Voto</label> <br>
        <select name="mark" id="mark">
            <?php for($mark = 18; $mark <= 30; $mark++) { ?>
                <option value="<?php echo e($mark); ?>" <?php if($exam->mark == $mark) { ?> selected <?php } ?> ><?php echo e($mark); ?></option>
            <?php } ?>
            <option value="30L" <?php if($exam->mark == "30L") { ?> selected <?php } ?> >30L</option>
        </select> <br><br>
        <input type="submit" value="Modifica Esame"> <br><br>
    </form>
    <form action="/exams/<?php echo e($exam->id); ?>" method="post">
        <?php echo csrf_field(); ?>
        <?php echo method_field('DELETE'); ?>
        <input type="submit" value="Elimina Esame">
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/kada/LaravelProjects/smartEdu/resources/views/exams/edit.blade.php ENDPATH**/ ?>