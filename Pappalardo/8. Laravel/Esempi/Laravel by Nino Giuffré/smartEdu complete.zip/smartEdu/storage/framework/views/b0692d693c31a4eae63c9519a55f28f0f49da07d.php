<?php $__env->startSection('content'); ?>
    <h1>Crea Corso</h1>
    <form action="/courses" method="post">
        <?php echo csrf_field(); ?>
        <label for="name">Nome</label> <br>
        <input type="text" name="name" id="name"> <br><br>
        <input type="submit" value="Crea Corso">
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/kada/LaravelProjects/smartEdu/resources/views/courses/create.blade.php ENDPATH**/ ?>