<?php $__env->startSection('content'); ?>
    <h1>Crea Esame</h1>
    <form action="/exams" method="post">
        <?php echo csrf_field(); ?>
        <label for="student_id">ID Studente</label> <br>
        <input type="number" name="student_id" id="student_id"> <br><br>
        <label for="course_id">ID Corso</label> <br>
        <input type="number" name="course_id" id="course_id"> <br><br>
        <label for="date">Data</label> <br>
        <input type="date" name="date" id="date"> <br><br>
        <label for="mark">Voto</label> <br>
        <select name="mark" id="mark">
            <?php for($mark = 18; $mark <= 30; $mark++) { ?>
                <option value="<?php echo e($mark); ?>"><?php echo e($mark); ?></option>
            <?php } ?>
            <option value="30L">30L</option>
        </select> <br><br>
        <input type="submit" value="Crea Esame">
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/kada/LaravelProjects/smartEdu/resources/views/exams/create.blade.php ENDPATH**/ ?>