<?php
    use App\Models\Student;
    use App\Models\Course;
?>

<?php $__env->startSection('content'); ?>
    <h1>Esami</h1>
    <ul>
        <?php $__currentLoopData = $exams; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $exam): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php
                $student = Student::find($exam->student_id);
                $course = Course::find($exam->course_id);
            ?>
            <li>
                <b>ID:</b> <?php echo e($exam->id); ?> <br>
                <b>STUDENTE:</b> <?php echo e($student->name); ?> <br>
                <b>MATRICOLA:</b> <?php echo e($student->code); ?> <br>
                <b>CORSO:</b> <?php echo e($course->name); ?> <br>
                <b>DATA:</b> <?php echo e($exam->date); ?> <br>
                <b>VOTO:</b> <?php echo e($exam->mark); ?> <br><br>
            </li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/kada/LaravelProjects/smartEdu/resources/views/exams/index.blade.php ENDPATH**/ ?>