@extends('layout')

@section('content')
    <h1>Crea Esame</h1>
    <form action="/exams" method="post">
        @csrf
        <label for="student_id">ID Studente</label> <br>
        <input type="number" name="student_id" id="student_id"> <br><br>
        <label for="course_id">ID Corso</label> <br>
        <input type="number" name="course_id" id="course_id"> <br><br>
        <label for="date">Data</label> <br>
        <input type="date" name="date" id="date"> <br><br>
        <label for="mark">Voto</label> <br>
        <select name="mark" id="mark">
            <?php for($mark = 18; $mark <= 30; $mark++) { ?>
                <option value="{{$mark}}">{{$mark}}</option>
            <?php } ?>
            <option value="30L">30L</option>
        </select> <br><br>
        <input type="submit" value="Crea Esame">
    </form>
@endsection
