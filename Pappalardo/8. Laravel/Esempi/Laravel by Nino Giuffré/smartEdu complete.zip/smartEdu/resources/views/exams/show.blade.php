@extends('layout')

@php
    use App\Models\Student;
    use App\Models\Course;

    $student = Student::find($exam->student_id);
    $course = Course::find($exam->course_id);
@endphp

@section('content')
    <h1>Esame</h1>
    <b>ID:</b> {{$exam->id}} <br>
    <b>STUDENTE:</b> {{$student->name}} <br>
    <b>MATRICOLA:</b> {{$student->code}} <br>
    <b>CORSO:</b> {{$course->name}} <br>
    <b>DATA:</b> {{$exam->date}} <br>
    <b>VOTO:</b> {{$exam->mark}} <br><br>
    <form action="/exams/{{$exam->id}}/edit" method="get">
        <input type="submit" value="Modifica/Elimina Esame">
    </form>
@endsection
