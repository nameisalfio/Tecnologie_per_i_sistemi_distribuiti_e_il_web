@extends('layout')

@section('content')
    <h1>Modifica/Elimina Studente</h1>
    <form action="/students/{{$student->id}}" method="post">
        @csrf
        @method('PATCH')
        <label for="name">Nome</label> <br>
        <input type="text" name="name" id="name" value="{{$student->name}}"> <br><br>
        <label for="code">Matricola</label> <br>
        <input type="text" name="code" id="code" value="{{$student->code}}"> <br><br>
        <input type="hidden" name="oldCode" id="oldCode" value="{{$student->code}}">
        <input type="submit" value="Modifica Studente"> <br><br>
    </form>
    <form action="/students/{{$student->id}}" method="post">
        @csrf
        @method('DELETE')
        <input type="submit" value="Elimina Studente">
    </form>
@endsection
