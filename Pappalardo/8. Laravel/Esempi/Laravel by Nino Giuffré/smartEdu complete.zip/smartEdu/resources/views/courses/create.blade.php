@extends('layout')

@section('content')
    <h1>Crea Corso</h1>
    <form action="/courses" method="post">
        @csrf
        <label for="name">Nome</label> <br>
        <input type="text" name="name" id="name"> <br><br>
        <input type="submit" value="Crea Corso">
    </form>
@endsection
