@extends('layout')

@section('content')
    <h1>Modifica/Elimina Corso</h1>
    <form action="/courses/{{$course->id}}" method="post">
        @csrf
        @method('PATCH')
        <label for="name">Nome</label> <br>
        <input type="text" name="name" id="name" value="{{$course->name}}"> <br><br>
        <input type="hidden" name="oldName" id="oldName" value="{{$course->name}}">
        <input type="submit" value="Modifica Corso"> <br><br>
    </form>
    <form action="/courses/{{$course->id}}" method="post">
        @csrf
        @method('DELETE')
        <input type="submit" value="Elimina Corso">
    </form>
@endsection
