@extends('layout')

@section('content')
    <h1>Studenti</h1>
    <ul>
        @foreach ($students as $student)
            <li>
                <b>ID:</b> {{$student->id}} <br>
                <b>NOME:</b> {{$student->name}} <br>
                <b>MATRICOLA:</b> {{$student->code}} <br><br>
            </li>
        @endforeach
    </ul>
@endsection
