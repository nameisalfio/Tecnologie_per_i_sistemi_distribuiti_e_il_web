@extends('layout')

@php
    use App\Models\Student;
    use App\Models\Course;
@endphp

@section('content')
    <h1>Esami</h1>
    <ul>
        @foreach ($exams as $exam)
            @php
                $student = Student::find($exam->student_id);
                $course = Course::find($exam->course_id);
            @endphp
            <li>
                <b>ID:</b> {{$exam->id}} <br>
                <b>STUDENTE:</b> {{$student->name}} <br>
                <b>MATRICOLA:</b> {{$student->code}} <br>
                <b>CORSO:</b> {{$course->name}} <br>
                <b>DATA:</b> {{$exam->date}} <br>
                <b>VOTO:</b> {{$exam->mark}} <br><br>
            </li>
        @endforeach
    </ul>
@endsection
