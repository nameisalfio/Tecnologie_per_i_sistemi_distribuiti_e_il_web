@extends('layout')

@section('content')
    <h1>Modifica/Elimina Esame</h1>
    <form action="/exams/{{$exam->id}}" method="post">
        @csrf
        @method('PATCH')
        <label for="student_id">ID Studente</label> <br>
        <input type="number" name="student_id" id="student_id" value="{{$exam->student_id}}"> <br><br>
        <input type="hidden" name="oldStudent" id="oldStudent" value="{{$exam->student_id}}">
        <label for="course_id">ID Corso</label> <br>
        <input type="number" name="course_id" id="course_id" value="{{$exam->course_id}}"> <br><br>
        <input type="hidden" name="oldCourse" id="oldCourse" value="{{$exam->course_id}}">
        <label for="date">Date</label> <br>
        <input type="date" name="date" id="date" value="{{$exam->date}}"> <br><br>
        <label for="mark">Voto</label> <br>
        <select name="mark" id="mark">
            <?php for($mark = 18; $mark <= 30; $mark++) { ?>
                <option value="{{$mark}}" <?php if($exam->mark == $mark) { ?> selected <?php } ?> >{{$mark}}</option>
            <?php } ?>
            <option value="30L" <?php if($exam->mark == "30L") { ?> selected <?php } ?> >30L</option>
        </select> <br><br>
        <input type="submit" value="Modifica Esame"> <br><br>
    </form>
    <form action="/exams/{{$exam->id}}" method="post">
        @csrf
        @method('DELETE')
        <input type="submit" value="Elimina Esame">
    </form>
@endsection
