@extends('layout')

@section('content')
    <h1>Crea Studente</h1>
    <form action="/students" method="post">
        @csrf
        <label for="name">Nome</label> <br>
        <input type="text" name="name" id="name"> <br><br>
        <label for="code">Matricola</label><br>
        <input type="text" name="code" id="code"> <br><br>
        <input type="submit" value="Crea Studente">
    </form>
@endsection
