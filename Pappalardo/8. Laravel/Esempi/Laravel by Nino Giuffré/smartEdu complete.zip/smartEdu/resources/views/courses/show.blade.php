@extends('layout')

@section('content')
    <h1>Corso</h1>
    <b>ID:</b> {{$course->id}} <br>
    <b>NOME:</b> {{$course->name}} <br><br>
    <form action="/courses/{{$course->id}}/edit" method="get">
        <input type="submit" value="Modifica/Elimina Corso">
    </form>
@endsection
