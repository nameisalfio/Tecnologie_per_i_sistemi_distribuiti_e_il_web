@extends('layout')

@section('content')
    <h1>Studente</h1>
    <b>ID:</b> {{$student->id}} <br>
    <b>NOME:</b> {{$student->name}} <br>
    <b>MATRICOLA:</b> {{$student->code}} <br><br>
    <form action="/students/{{$student->id}}/edit" method="get">
        <input type="submit" value="Modifica/Elimina Studente">
    </form>
@endsection
