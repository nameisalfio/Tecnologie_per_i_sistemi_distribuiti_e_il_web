@extends('layout')

@section('content')
    <h1>Corsi</h1>
    <ul>
        @foreach ($courses as $course)
            <li>
                <b>ID:</b> {{$course->id}} <br>
                <b>NOME:</b> {{$course->name}} <br><br>
            </li>
        @endforeach
    </ul>
@endsection
