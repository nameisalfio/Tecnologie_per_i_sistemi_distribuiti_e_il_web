@extends('layout')

@section('content')
    <h1>Projects Operations</h1>

    <form action="/projects/create" method="get">
        <input type="submit" value="Create Project"> <br><br><br>
    </form>

    <form action="/projects" method="get">
        <input type="submit" value="Show All Projects"> <br><br><br>
    </form>

    <form action="/projects/help_show" method="post">
        @csrf
        <label for="id">Project ID </label> <br>
        <input type="number" name="id" id="id"> <br><br>
        <input type="submit" value="Search Project"> <br><br><br>
    </form>

    <form action="/projects" method="post">
        @csrf
        @method('DELETE')
        <input type="submit" value="Delete All Projects"> <br><br><br>
    </form>

    <h1>Tasks Operations</h1>

    <form action="/tasks/create" method="get">
        <input type="submit" value="Create Task"> <br><br><br>
    </form>

    <form action="/tasks" method="get">
        <input type="submit" value="Show All Tasks"> <br><br><br>
    </form>

    <form action="/tasks/help_show" method="post">
        @csrf
        <label for="id">Task ID </label> <br>
        <input type="number" name="id" id="id"> <br><br>
        <input type="submit" value="Search Task"> <br><br><br>
    </form>

    <form action="/tasks" method="post">
        @csrf
        @method('DELETE')
        <input type="submit" value="Delete All Tasks">
    </form>
@endsection
